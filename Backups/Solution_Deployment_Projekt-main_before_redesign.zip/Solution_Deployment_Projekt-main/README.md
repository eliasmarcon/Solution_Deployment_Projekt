# Solution_Deployment_Projekt
## Deployed to
https://sdc-project-cmp.azurewebsites.net/
